# AI course design toolkit

Start with CONTRIBUTING.md and RELEASE_WORKFLOW.md. The skills/ folder contains three self-contained SKILL.md packages with YAML frontmatter. Read them as plain Markdown, attach a relevant SKILL.md to an AI assistant, or place an extracted skill folder in your assistant's configured skill directory. Installation depends on the assistant; no automatic installer is included.

For this course, inspect A2 at https://rainy1993.github.io/fintech-course/a2/ and its downloadable Python examples. The skills document reusable decisions; they do not invoke tools, access private files, or grant publishing permission by themselves.

Run python3 check_site.py /path/to/website to check local resource links, HTML fragments, duplicate HTML IDs, and ZIP integrity. The checker requires Python 3.9+ and no third-party packages. It does not validate statistical results, JavaScript behavior, or accessibility.
