---
name: course-lesson-design
description: Design or revise an interactive course lesson when learning goals, prerequisite order, explanatory text, experiments, and assessment need to work together.
---
# Design an interactive lesson

Start from the requested learning outcome and the existing lesson. Preserve the instructor's scope, audience, language, and accepted terminology. Ask only for missing information that changes the lesson.

## Decisions to make
- Write an observable outcome: what should a learner calculate, interpret, or distinguish?
- Identify the minimum prerequisite chain. Introduce notation before using it. Do not introduce a later model simply to explain today's statistic.
- Use a motivating situation when it makes the learning question concrete. Keep the scenario separate from evidence.
- Give each interaction a learning purpose: predict, change one variable, observe, then explain. A slider without an interpretable consequence adds little.
- Prefer a short definition, a legible equation, and named parameters over repeated explanatory paragraphs. Keep the inference limit next to the conclusion it qualifies.
- Write understanding checks that distinguish likely misconceptions, with feedback explaining why an answer works.

## Evidence and review
Use the supplied dataset and verify external technical claims against primary sources. Distinguish an observed sample relationship from future forecasting performance. Do not invent evidence of learning effectiveness.

Deliver a coherent lesson or scoped revision, plus the checks performed and any unresolved teaching decision. If the instructor requests discussion first, offer concrete alternatives without editing.

## A2 example
The sequence is prices → simple/log returns → distribution versus time order → ACF and Ljung–Box → memory. The shuffle experiment keeps the set of returns fixed while changing their order. An AR model is deliberately outside the introductory explanation of ACF. These are A2 choices, not a universal lesson template.
