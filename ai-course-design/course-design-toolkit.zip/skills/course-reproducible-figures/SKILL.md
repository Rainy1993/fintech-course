---
name: course-reproducible-figures
description: Create or revise course statistics figures with downloadable Python examples when the web display and reproduction must agree on data, units, estimators, and parameters.
---
# Build reproducible course figures

Inspect the existing browser calculation and source data before writing a second implementation. Record the figure contract: data columns and window, missing-value handling, units, transformation, estimator, parameter defaults, and any random seed.

## Keep the two implementations consistent
- Match the statistical definition, not only the appearance. A correlation of overlapping pairs and an ACF using a whole-sample denominator can differ.
- Keep percentages and percentage points explicit. State whether standard deviation uses a sample or population denominator.
- For a KDE, distinguish an absolute bandwidth from a library's dimensionless bandwidth factor.
- For simulated data, specify the generator and seed. Equal seeds across different generators do not guarantee equal samples.
- Make chart controls and labels read the same state as the calculation. Give changing settings an observable meaning.
- Use equal units and axis scales where geometric comparison requires them, especially yesterday-versus-today scatter plots.

Provide a standalone Python script with editable parameters and clear dependency and data instructions. Use paths relative to the script or an explicit input path; never depend on the author's private folders. A static reproduction may match a selected interactive state; state which one.

## Verify observable agreement
Run the script against the packaged data. Compare representative numbers and endpoints with the web implementation using a tolerance appropriate to floating-point and displayed rounding. Check the downloadable code, inline code, and bundle are consistent. Open the chart to inspect ticks, units, and clipping.

## A2 example
A2 uses 93 BTC daily prices and 92 log returns. Its BTC ACF uses a whole-sample denominator; the simulated memory charts use overlapping-pair Pearson correlations. Preserve and explain this distinction when reproducing them rather than silently substituting one estimator for the other.
