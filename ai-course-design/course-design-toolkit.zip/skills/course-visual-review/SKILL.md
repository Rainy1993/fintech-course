---
name: course-visual-review
description: Inspect and improve course webpage readability when formulas, charts, callout boxes, responsive layouts, or interaction states have visual defects.
---
# Review a course page visually

Read the local styling and inspect the rendered page before editing. Preserve the requested visual language and content scope. Treat a screenshot as evidence of a visible defect, not as a complete account of the underlying layout.

## Formulas
- Keep a variable close to its relation sign with balanced spacing on both sides.
- Use one shared relation column for multi-line derivations. Align equals and approximate-equals signs. Center a relation sign on a fraction's rule.
- Keep subscripts attached, limits legible, and terms together where possible. Do not use repeated spaces to align mathematical content.
- Use a single line for a short calculation if it fits; allow structured wrapping at narrow widths.

## Charts and layout
- Check ticks, units, label clipping, plot proportions, caption lengths, and the balance between adjacent figures.
- Give color a stable meaning. Use a small set of existing box types; do not invent a new fill for every example.
- Check default, final, replay, selected, expanded, and error states where relevant to the change.
- Check at a desktop width and a narrow mobile width. Keep native keyboard focus, readable labels, and a reduced-motion alternative.

## Verify the fix
Inspect the actual computed layout and a fresh screenshot after the change. Account for CSS cascade and stale asset caches. A selector existing in a stylesheet does not prove that it wins. Report the states and widths actually inspected; do not claim a comprehensive accessibility audit from a small visual check.

## A2 example
A2 revisions aligned = and ≈, reduced excessive left-hand formula spacing, fixed clipped price-axis labels, and equalized scatter-plot axes. Convert these into reusable checks rather than hard-coded A2 pixel dimensions.
