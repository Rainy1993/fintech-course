FinTech: Data, Risk, and Digital Assets — Python examples

1. Install Python 3 and the packages: python -m pip install -r requirements.txt
2. Keep avg_price_per_day.csv in the same folder as the scripts.
3. Run a script, for example: python btc_acf_ljung_box.py

Scripts reproduce the same data and formulas as the course website.
These are static Matplotlib figures. Change the parameters near the top
of each script to reproduce different website settings.
For the shuffle experiment, set SHUFFLE = True; SEED makes a permutation repeatable.
The simulator uses the website's deterministic shock sequence.
The data source is Blockchain Research Center: https://blockchain-research-center.com
